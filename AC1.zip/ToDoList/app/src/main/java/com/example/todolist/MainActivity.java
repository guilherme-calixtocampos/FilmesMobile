package com.example.todolist;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private FilmesDbHelper databaseHelper;
    private ArrayList<String> listaFilmes;
    private ArrayList<Integer> listaIds;
    private EditText edtTitulo, edtDiretor, edtAno, edtNota;
    private Spinner spinnerGenero;
    private RadioButton radioSim, radioNao;
    private Button btnSalvar;
    private ListView listViewFilmes;

    private int filmeIdSelecionado = -1;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtTitulo = findViewById(R.id.edtTitulo);
        edtDiretor = findViewById(R.id.edtDescricao);
        edtAno = findViewById(R.id.edtAno);
        edtNota = findViewById(R.id.edtNota);
        spinnerGenero = findViewById(R.id.edtGenero);
        radioSim = findViewById(R.id.radio_opcao1);
        radioNao = findViewById(R.id.radio_opcao2);
        btnSalvar = findViewById(R.id.btnSalvar);
        listViewFilmes = findViewById(R.id.listViewFilmes);

        databaseHelper = new FilmesDbHelper(this);
        carregarFilmes();

        btnSalvar.setOnClickListener(v -> {
            if (filmeIdSelecionado == -1) {
                salvarFilme();
            } else {
                atualizarFilme();
            }
        });

        listViewFilmes.setOnItemClickListener((parent, view, position, id) -> {
            filmeIdSelecionado = listaIds.get(position);
            String[] dados = listaFilmes.get(position).split(" - ");

            edtTitulo.setText(dados[1]);
            edtDiretor.setText(dados[2]);
            edtAno.setText(dados[3]);
            edtNota.setText(dados[4]);

            // Seleciona o gênero no Spinner
            ArrayAdapter generoAdapter = (ArrayAdapter) spinnerGenero.getAdapter();
            int spinnerPos = generoAdapter.getPosition(dados[5]);
            spinnerGenero.setSelection(spinnerPos);

            if (dados[6].equals("Sim")) {
                radioSim.setChecked(true);
            } else {
                radioNao.setChecked(true);
            }

            btnSalvar.setText("Atualizar");
        });

        listViewFilmes.setOnItemLongClickListener((adapterView, view, pos, l) -> {
            int idFilme = listaIds.get(pos);
            int deletado = databaseHelper.excluirFilme(idFilme);
            if (deletado > 0) {
                Toast.makeText(this, "Filme excluído!", Toast.LENGTH_SHORT).show();
                carregarFilmes();
            }
            return true;
        });
    }

    private void carregarFilmes() {
        Cursor cursor = databaseHelper.listarFilmes();
        listaFilmes = new ArrayList<>();
        listaIds = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String titulo = cursor.getString(1);
                String diretor = cursor.getString(2);
                int ano = cursor.getInt(3);
                int nota = cursor.getInt(4);
                String genero = cursor.getString(5);
                int viuNoCinema = cursor.getInt(6);

                String viu = (viuNoCinema == 1) ? "Sim, já vi no cinema" : "Não, não vi no cinema";
                listaFilmes.add(" - " + titulo + " - " + diretor + " - " + ano + " - " + nota + " - " + genero + " - " + viu);
                listaIds.add(id);
            } while (cursor.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaFilmes);
        listViewFilmes.setAdapter(adapter);
    }

    private void salvarFilme() {
        String titulo = edtTitulo.getText().toString().trim();
        String diretor = edtDiretor.getText().toString().trim();
        String anoStr = edtAno.getText().toString().trim();
        String notaStr = edtNota.getText().toString().trim();
        String genero = spinnerGenero.getSelectedItem().toString();
        int viuNoCinema = radioSim.isChecked() ? 1 : 0;

        if (titulo.isEmpty() || diretor.isEmpty() || anoStr.isEmpty() || notaStr.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int ano = Integer.parseInt(anoStr);
            int nota = Integer.parseInt(notaStr);

            long resultado = databaseHelper.inserirFilme(titulo, diretor, ano, nota, genero, viuNoCinema);
            if (resultado != -1) {
                Toast.makeText(this, "Filme salvo com sucesso!", Toast.LENGTH_SHORT).show();
                limparCampos();
                carregarFilmes();
            } else {
                Toast.makeText(this, "Erro ao salvar!", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Ano e nota devem ser números!", Toast.LENGTH_SHORT).show();
        }
    }

    private void atualizarFilme() {
        String titulo = edtTitulo.getText().toString().trim();
        String diretor = edtDiretor.getText().toString().trim();
        String anoStr = edtAno.getText().toString().trim();
        String notaStr = edtNota.getText().toString().trim();
        String genero = spinnerGenero.getSelectedItem().toString();
        int viuNoCinema = radioSim.isChecked() ? 1 : 0;

        if (titulo.isEmpty() || diretor.isEmpty() || anoStr.isEmpty() || notaStr.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int ano = Integer.parseInt(anoStr);
            int nota = Integer.parseInt(notaStr);

            int resultado = databaseHelper.atualizarFilme(filmeIdSelecionado, titulo, diretor, ano, nota, genero, viuNoCinema);
            if (resultado > 0) {
                Toast.makeText(this, "Filme atualizado com sucesso!", Toast.LENGTH_SHORT).show();
                limparCampos();
                carregarFilmes();
            } else {
                Toast.makeText(this, "Erro ao atualizar!", Toast.LENGTH_SHORT).show();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Ano e nota devem ser números!", Toast.LENGTH_SHORT).show();
        }
    }

    private void limparCampos() {
        edtTitulo.setText("");
        edtDiretor.setText("");
        edtAno.setText("");
        edtNota.setText("");
        spinnerGenero.setSelection(0);
        radioSim.setChecked(false);
        radioNao.setChecked(false);
        btnSalvar.setText("Salvar");
        filmeIdSelecionado = -1;
    }
}
