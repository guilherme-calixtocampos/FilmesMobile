import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Tasks extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "tasks.db"; // Nome do banco de dados
    private static final int DATABASE_VERSION = 1; // Versão do banco de dados

    private static final String TABLE_NAME = "tasks"; // Nome da tabela

    // Definição correta das colunas
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_TITLE = "title";
    private static final String COLUMN_DESCRIPTION = "description";
    private static final String COLUMN_STATUS = "status";

    public Tasks(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // String SQL para criar a tabela 'tasks' com colunas id, título, descrição e status
        String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + " ("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "  // ID auto-incrementado
                + COLUMN_TITLE + " TEXT, "  // Coluna título do tipo texto
                + COLUMN_DESCRIPTION + " TEXT, "  // Coluna descrição do tipo texto
                + COLUMN_STATUS + " INTEGER)"; // Coluna status do tipo inteiro

        // Executa o comando SQL para criar a tabela
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Apaga a tabela existente, se houver
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);

        // Cria a tabela novamente
        onCreate(db);
    }

    public long inserirTarefa(String title, String description, int status) {
        // Obtém o banco de dados para escrita
        SQLiteDatabase db = this.getWritableDatabase();

        // Cria um conjunto de valores para inserir no banco
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_STATUS, status);

        // Insere os valores na tabela e retorna o ID do novo registro inserido
        return db.insert(TABLE_NAME, null, values);
    }

    public Cursor listarTarefas() {
        // Obtém o banco de dados para leitura
        SQLiteDatabase db = this.getReadableDatabase();

        // Retorna um Cursor contendo todos os registros da tabela
        return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
    }

    public int atualizarTarefa(String id, String title, String description, int status) {
        // Obtém o banco de dados para escrita
        SQLiteDatabase db = this.getWritableDatabase();

        // Cria um conjunto de valores para atualização
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, title);
        values.put(COLUMN_DESCRIPTION, description);
        values.put(COLUMN_STATUS, status);

        // Atualiza o registro que tem o ID correspondente e retorna o número de linhas afetadas
        return db.update(TABLE_NAME, values, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }

    public int excluirTarefa(int id) {
        // Obtém o banco de dados para escrita
        SQLiteDatabase db = this.getWritableDatabase();

        // Deleta o registro que tem o ID correspondente e retorna o número de linhas afetadas
        return db.delete(TABLE_NAME, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
    }


}
